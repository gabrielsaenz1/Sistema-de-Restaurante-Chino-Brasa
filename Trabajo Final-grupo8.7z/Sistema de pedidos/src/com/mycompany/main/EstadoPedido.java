package com.mycompany.main;

public enum EstadoPedido {
    PENDIENTE,
    EN_COCINA,
    ENTREGADO, ENCOCINA
}
